
from django.urls import path,include
from . import views
from rest_framework.routers import DefaultRouter


router = DefaultRouter()
router.register(r'article', views.ArticleViewset, basename='article')
router.register(r'users', views.UserViewset, basename='users')
# urlpatterns = router.urls

urlpatterns = [
    path('api/', include(router.urls) ),
]
