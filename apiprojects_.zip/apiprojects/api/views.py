from rest_framework import generics, mixins
from rest_framework import viewsets
from .models import Article
from .serializers import ArticleSerializers, UserSerializers
from rest_framework.authentication import SessionAuthentication, BasicAuthentication, TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User

# Create your views here.

class ArticleViewset(viewsets.ModelViewSet, mixins.ListModelMixin):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializers
    # authentication_classes = [BasicAuthentication, SessionAuthentication]
    authentication_classes = (TokenAuthentication,)
    permission_classes = [IsAuthenticated]


class UserViewset(viewsets.ModelViewSet):
    queryset = User.objects.all()

    serializer_class = UserSerializers
