import React,{useState, useEffect} from 'react'
import APIService from '../APIService'

function From(props) {
    const [title, setTile] = useState("")
    const [description, setdescription] = useState("")
    useEffect(()=>{
        setTile(props.article.title)
        setdescription(props.article.description)
    },[props.article])
    const updateArticle = ()=>{
        APIService.UpdateArticle(props.article.id, {title,description})
        .then(resp=>props.updatedInformtion(resp))

    }
    const insterArticle= ()=>{
            APIService.InsterArticle({title,description})
            .then(resp=>props.insertformation(resp))
    }
  return (
    <div>
       {props.article?(
            <div className='mb-3'>
                <lable htmlFor= "title" class = "form-lable">Title</lable>
                <input type="text" className='form-control' id='title' placeholder='please enter title'
                value={title} onChange={e=> setTile(e.target.value)}/>


                <lable htmlFor= "description" class = "form-lable">Description</lable>
                <textarea className='form-control' id= "description" rows="5"
                value={description} onChange={e=> setdescription(e.target.value)}
                ></textarea>

                <br/>
                {
                    props.article.id ? <button onClick={updateArticle} className='btn btn-success'>Update</button>
                    : <button onClick={insterArticle} className='btn btn-success'>Insert</button>
                }
                
            </div>
       ) : null}
    </div>
  )
}

export default From
