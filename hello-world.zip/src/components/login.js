import React from 'react'

function login() {
  return (
    <div>
      <h1>pls LOGIN</h1>
    </div>
  )
}

export default login
