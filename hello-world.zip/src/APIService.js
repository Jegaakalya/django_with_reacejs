import React, { Component } from 'react'

export class APIService  {
    static UpdateArticle(article_id, body){
        return fetch(`http://127.0.0.1:8000/api/article/${article_id}/`,
        {"method":"PUT",
        headers: {"Content-Type": "application/json",
                  "Authorization": "Token 2c05f6cad46ca98508188a7b014672ab3838db29"}
        , 
        body:JSON.stringify(body)}).then(resp=>resp.json())
    }
   static InsterArticle (body){
    return fetch(`http://127.0.0.1:8000/api/article/`,
        {"method":"POST",
        headers: {"Content-Type": "application/json",
                  "Authorization": "Token 2c05f6cad46ca98508188a7b014672ab3838db29"}
        , 
        body:JSON.stringify(body)})
        .then(resp=>resp.json())
   }

   static  DeleteArticle(article_id){
    return fetch(`http://127.0.0.1:8000/api/article/${article_id}/`,
    {"method":"DELETE",
    headers: {"Content-Type": "application/json",
              "Authorization": "Token 2c05f6cad46ca98508188a7b014672ab3838db29"}
    , 
     }) 
   }
}

export default APIService
