import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import ArticleList from './components/ArticleList';
import From from './components/From';

function App() {
  const [articles, SetArticles]= useState([])
  const [editarticles, SetEditArticles]= useState(null)


  useEffect(()=>{
    fetch("http://127.0.0.1:8000/api/article/",{"method":"GET",
      headers: {"Content-Type": "application/json",
                "Authorization": "Token 2c05f6cad46ca98508188a7b014672ab3838db29"}})
      .then(resp =>resp.json())
      .then(resp=>SetArticles(resp))    
      .catch(error =>console.log(error))      
  },[])

  const editbtn= (article)=>{
    SetEditArticles(article)
  }

  const updatedInformtion = (article)=>{
    const new_article = articles.map(myarticle =>{
      if(myarticle.id === article.id){
        return article
      }
      else{
        return myarticle;
      }
    })
    SetArticles(new_article);
  }
  const articleForm = ()=>{
    SetEditArticles({title:"", description:""})
  }
const insertformation = (article_)=>{
  const new_articles=[...articles, article_]
  SetArticles(new_articles)
   
}
const deleteBtn = (article)=>{
const new_article = articles.filter(myarticle=>{
  if (myarticle.id ===article.id){
    return false; 
  }
  return true;
})
SetArticles(new_article)
}

  return (
    <div className="App">
       <div className='row'>
       <div className='col'>
        <h1>  welcome to django and react js blog app</h1>
        <br/>
        <br/>
        </div>
        <div className='clo'>
          <button onClick={articleForm}  className='btn btn-primary'>insert Article</button>
        </div>
      
        
        </div>
         <ArticleList  articles={articles} editbtn={editbtn} deleteBtn={deleteBtn}/>
         {editarticles? <From article = {editarticles} updatedInformtion={updatedInformtion} insertformation={insertformation}/> : null}
         
      
    </div>
  );
}

export default App;
